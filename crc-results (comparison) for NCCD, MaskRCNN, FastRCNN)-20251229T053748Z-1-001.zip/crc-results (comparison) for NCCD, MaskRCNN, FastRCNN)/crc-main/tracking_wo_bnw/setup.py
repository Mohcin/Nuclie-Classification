from setuptools import setup, find_packages

setup(name='tracktor',
      packages=['tracktor'],
      package_dir={'':'src'},
      version='0.0.1',
      install_requires=[],)
